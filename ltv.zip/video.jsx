// video.jsx — faux live TV screen with broadcast overlays
const { useState: useStateV, useEffect: useEffectV } = React;

function ScreenScene({ mode, channel, on }) {
  if (!on) {
    return (
      <div className="scene scene-standby">
        <div className="standby-mark"><Icon name="power" size={40} /></div>
        <div className="standby-text">STANDBY</div>
        <div className="standby-sub">Box is powered off — press Power to wake</div>
      </div>
    );
  }
  if (mode === "bars") {
    return (
      <div className="scene scene-bars">
        <div className="bars-row">
          {["#c9c9c9", "#cfcf2e", "#2ecfcf", "#2ecf45", "#cf2ecf", "#cf2e2e", "#2e45cf"].map((c, i) => (
            <div key={i} style={{ background: c }} />
          ))}
        </div>
        <div className="bars-foot" />
      </div>
    );
  }
  if (mode === "striped") {
    return (
      <div className="scene scene-striped">
        <span className="ph-label">LIVE CAPTURE · HDMI&nbsp;IN · 1080i</span>
      </div>
    );
  }
  // broadcast
  return (
    <div className="scene scene-broadcast" data-genre={channel.genre}>
      <div className="bc-sky" />
      <div className="bc-glow" />
      <div className="bc-horizon" />
      <div className="bc-vignette" />
    </div>
  );
}

function LiveScreen(props) {
  const { channel, on, muted, volume, mode, capture, onRefresh, onMuteStream, onFullscreen } = props;
  const [now, setNow] = useStateV(() => new Date());
  useEffectV(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const ss = String(now.getSeconds()).padStart(2, "0");

  const live = on && capture === "online";

  return (
    <div className="screen">
      <ScreenScene mode={mode} channel={channel} on={live} />

      {/* overlays only when live */}
      {live && (
        <div className="screen-overlays">
          <div className="ov-top">
            <div className="bug">
              <span className="bug-num">{channel.num}</span>
              <span className="bug-name">{channel.name}</span>
              <span className="bug-hd">HD</span>
            </div>
            <div className="ov-top-right">
              <div className="live-badge"><span className="live-dot" />LIVE</div>
              <div className="clock">{hh}:{mm}<span className="clock-s">:{ss}</span></div>
            </div>
          </div>

          <div className="ov-bottom">
            <div className="lowerthird">
              <div className="lt-bar" />
              <div className="lt-body">
                <div className="lt-kicker">{channel.genre} · NOW</div>
                <div className="lt-title">{channel.program}</div>
                <div className="lt-next">Next: {channel.next}</div>
              </div>
              <div className="lt-prog">
                <div className="lt-prog-fill" style={{ width: channel.progress + "%" }} />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* hover controls */}
      <div className="screen-controls">
        <button className="sc-btn" onClick={onRefresh} title="Refresh stream"><Icon name="refresh" size={18} /></button>
        <button className={"sc-btn" + (muted ? " is-on" : "")} onClick={onMuteStream} title="Mute stream">
          <Icon name={muted ? "mute" : "volume"} size={18} />
        </button>
        <button className="sc-btn" onClick={onFullscreen} title="Fullscreen"><Icon name="fullscreen" size={18} /></button>
      </div>

      {/* volume flash handled by parent via key prop */}
      {live && muted && <div className="screen-mute-flag"><Icon name="mute" size={16} /> MUTED</div>}
    </div>
  );
}

window.LiveScreen = LiveScreen;
