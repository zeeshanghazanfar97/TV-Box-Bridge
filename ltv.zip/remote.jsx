// remote.jsx — the soft remote control panel
const { useState: useStateR } = React;

function PressBtn({ className = "", onClick, title, disabled, children }) {
  const [p, setP] = useStateR(false);
  return (
    <button
      type="button"
      className={className + (p ? " pressed" : "")}
      title={title}
      disabled={disabled}
      onClick={(e) => { setP(true); setTimeout(() => setP(false), 240); onClick && onClick(e); }}
    >
      {children}
    </button>
  );
}

function Rocker({ label, icon, plusTitle, minusTitle, onPlus, onMinus, accent, disabled }) {
  return (
    <div className={"rocker" + (accent ? " rocker-accent" : "")}>
      <PressBtn className="rocker-btn rocker-plus" onClick={onPlus} title={plusTitle} disabled={disabled}>
        <Icon name="plus" size={24} stroke={2.4} />
      </PressBtn>
      <div className="rocker-readout">
        <Icon name={icon} size={19} className="rocker-ic" />
        <div className="rocker-label">{label}</div>
      </div>
      <PressBtn className="rocker-btn rocker-minus" onClick={onMinus} title={minusTitle} disabled={disabled}>
        <Icon name="minus" size={24} stroke={2.4} />
      </PressBtn>
    </div>
  );
}

function Remote({ s, h, onClose }) {
  const off = !s.on;
  return (
    <aside className="remote" data-off={off ? "true" : "false"}>
      {/* ── Title bar ───────────────────────────── */}
      <div className="remote-bar">
        <div className="remote-bar-title">
          <span className="remote-grip" />
          Remote
        </div>
        <span className="remote-bar-hint">IR · one-way</span>
        <button className="remote-close" onClick={onClose} title="Close remote (watch TV)">
          <Icon name="exit" size={16} />
        </button>
      </div>

      <div className="remote-body">
      {/* ── Power + Mute ───────────────────────── */}
      <div className="r-toprow">
        <PressBtn className={"btn-power" + (s.on ? " is-on" : "")} onClick={h.power} title="Power">
          <Icon name="power" size={24} stroke={2.4} />
          <span>{s.on ? "On" : "Off"}</span>
        </PressBtn>
        <PressBtn className={"btn-mute" + (s.muted ? " is-on" : "")} onClick={h.mute} title="Mute" disabled={off}>
          <Icon name={s.muted ? "mute" : "volume"} size={22} />
          <span>{s.muted ? "Muted" : "Mute"}</span>
        </PressBtn>
      </div>

      {/* ── Primary: Volume + Channel ──────────── */}
      <div className="r-primary">
        <Rocker
          label="VOL" icon="volume"
          plusTitle="Volume Up" minusTitle="Volume Down"
          onPlus={h.volUp} onMinus={h.volDown} disabled={off}
        />
        <Rocker
          label="CH" icon="tvav" accent
          plusTitle="Channel Up" minusTitle="Channel Down"
          onPlus={h.chUp} onMinus={h.chDown} disabled={off}
        />
      </div>

      {/* ── Navigation d-pad ──────────────────── */}
      <div className="r-section">
        <div className="r-head"><span>Navigate</span></div>
        <div className="dpad">
          <PressBtn className="dpad-btn dpad-up" onClick={() => h.nav("Up")} title="Up" disabled={off}><Icon name="up" size={22} /></PressBtn>
          <PressBtn className="dpad-btn dpad-left" onClick={() => h.nav("Left")} title="Left" disabled={off}><Icon name="left" size={22} /></PressBtn>
          <PressBtn className="dpad-ok" onClick={h.ok} title="OK / Select" disabled={off}>OK</PressBtn>
          <PressBtn className="dpad-btn dpad-right" onClick={() => h.nav("Right")} title="Right" disabled={off}><Icon name="right" size={22} /></PressBtn>
          <PressBtn className="dpad-btn dpad-down" onClick={() => h.nav("Down")} title="Down" disabled={off}><Icon name="down" size={22} /></PressBtn>
        </div>
        <div className="r-trio">
          <PressBtn className="btn-ghost" onClick={h.back} title="Back" disabled={off}><Icon name="back" size={18} /><span>Back</span></PressBtn>
          <PressBtn className="btn-ghost" onClick={h.menu} title="Menu / Exit" disabled={off}><Icon name="menu" size={18} /><span>Menu</span></PressBtn>
          <PressBtn className="btn-ghost" onClick={h.info} title="Info" disabled={off}><Icon name="info" size={18} /><span>Info</span></PressBtn>
        </div>
      </div>

      {/* ── Go to channel ─────────────────────── */}
      <div className="r-section">
        <div className="r-head">
          <span>Go to channel</span>
          <button className={"head-toggle" + (s.keypadOpen ? " is-on" : "")} onClick={h.toggleKeypad}>
            <Icon name="numpad" size={15} /> Keypad
          </button>
        </div>
        <div className="gotorow">
          <div className="goto-input">
            <span className="goto-pre">CH</span>
            <input
              inputMode="numeric" placeholder="—" maxLength={4}
              value={s.chInput} disabled={off}
              onChange={(e) => h.setChInput(e.target.value.replace(/[^0-9]/g, ""))}
              onKeyDown={(e) => { if (e.key === "Enter") h.go(); }}
            />
          </div>
          <PressBtn className="btn-accent goto-btn" onClick={h.go} title="Go" disabled={off || !s.chInput}>Go</PressBtn>
        </div>
        <div className={"keypad" + (s.keypadOpen ? " open" : "")}>
          <div className="keypad-grid">
            {[1,2,3,4,5,6,7,8,9].map((d) => (
              <PressBtn key={d} className="numkey" onClick={() => h.pressDigit(String(d))} disabled={off}>{d}</PressBtn>
            ))}
            <PressBtn className="numkey numkey-util" onClick={h.clearInput} disabled={off} title="Clear">⌫</PressBtn>
            <PressBtn className="numkey" onClick={() => h.pressDigit("0")} disabled={off}>0</PressBtn>
            <PressBtn className="numkey numkey-go" onClick={h.go} disabled={off || !s.chInput} title="Go">Go</PressBtn>
          </div>
        </div>
      </div>

      {/* ── More controls drawer ──────────────── */}
      <div className="r-section r-drawer-sec">
        <button className={"drawer-toggle" + (s.drawerOpen ? " is-open" : "")} onClick={h.toggleDrawer}>
          <span><Icon name="bolt" size={16} /> More controls</span>
          <Icon name={s.drawerOpen ? "up" : "down"} size={18} />
        </button>
        <div className={"drawer" + (s.drawerOpen ? " open" : "")}>
          <div className="drawer-inner">
            <div className="drawer-sublabel">Sources &amp; guide</div>
            <div className="drawer-grid">
              {[
                ["guide", "Guide", "EPG"],
                ["star", "Favorites", "FAV"],
                ["tvav", "TV / AV", "TV/AV"],
                ["audio", "Audio", "Audio"],
                ["sub", "Subtitles", "SUB"],
                ["media", "Media", "MEDIA"],
              ].map(([ic, lab, cmd]) => (
                <PressBtn key={cmd} className="advkey" onClick={() => h.adv(cmd, lab)} disabled={off}>
                  <Icon name={ic} size={20} /><span>{lab}</span>
                </PressBtn>
              ))}
            </div>
            <div className="drawer-sublabel">Playback</div>
            <div className="transport">
              <PressBtn className="tpkey" onClick={() => h.adv("Rewind", "Rewind")} disabled={off} title="Rewind"><Icon name="rewind" size={18} /></PressBtn>
              <PressBtn className="tpkey" onClick={() => h.adv("Play/Pause", "Play / Pause")} disabled={off} title="Play / Pause"><Icon name="play" size={18} /></PressBtn>
              <PressBtn className="tpkey" onClick={() => h.adv("Stop", "Stop")} disabled={off} title="Stop"><Icon name="stop" size={18} /></PressBtn>
              <PressBtn className="tpkey" onClick={() => h.adv("Forward", "Fast forward")} disabled={off} title="Fast forward"><Icon name="forward" size={18} /></PressBtn>
              <PressBtn className="tpkey tpkey-rec" onClick={() => h.adv("Record", "Record")} disabled={off} title="Record"><Icon name="record" size={16} /></PressBtn>
            </div>
          </div>
        </div>
      </div>
      </div>
    </aside>
  );
}

window.Remote = Remote;
