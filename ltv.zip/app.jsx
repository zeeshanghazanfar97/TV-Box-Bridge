// app.jsx — TV Box Control dashboard root
const { useState, useEffect, useRef } = React;

const CHANNELS = [
  { num: "204", name: "CINEMAX HD",   genre: "MOVIES",    program: "The Long Afternoon", next: "Night Shift · 22:00", progress: 62 },
  { num: "101", name: "NEWS NOW",     genre: "NEWS",      program: "World at Ten",        next: "Market Watch · 22:30", progress: 38 },
  { num: "312", name: "SPORTS 1 HD",  genre: "SPORTS",    program: "Premier Live: Derby", next: "Post-Match · 22:15", progress: 74 },
  { num: "508", name: "NAT GEO WILD", genre: "NATURE",    program: "Coasts of Patagonia", next: "Deep Blue · 22:05",  progress: 24 },
  { num: "622", name: "FOOD NETWORK", genre: "LIFESTYLE", program: "Fire & Smoke",        next: "Bakeoff · 22:00",    progress: 50 },
  { num: "077", name: "RETRO TOONS",  genre: "KIDS",      program: "Cosmic Cadets",       next: "Robo Rangers · 21:45", progress: 88 },
];

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#4d8dff",
  "preview": "desktop",
  "remoteStyle": "subtle",
  "size": "regular",
  "video": "broadcast",
  "toasts": true
}/*EDITMODE-END*/;

function cmdIcon(label) {
  const l = label.toLowerCase();
  if (l.includes("volume")) return "volume";
  if (l.includes("mute")) return "mute";
  if (l.includes("channel up")) return "up";
  if (l.includes("channel down")) return "down";
  if (l.includes("going to") || l.includes("tune")) return "numpad";
  if (l.includes("power")) return "power";
  if (l.includes("up")) return "up";
  if (l.includes("down")) return "down";
  if (l.includes("left")) return "left";
  if (l.includes("right")) return "right";
  if (l.includes("ok")) return "media";
  if (l.includes("back")) return "back";
  if (l.includes("menu")) return "menu";
  if (l.includes("info")) return "info";
  if (l.includes("guide") || l.includes("epg")) return "guide";
  if (l.includes("fav")) return "star";
  if (l.includes("tv/av")) return "tvav";
  if (l.includes("audio")) return "audio";
  if (l.includes("subtitle")) return "sub";
  if (l.includes("media")) return "media";
  if (l.includes("record")) return "record";
  if (l.includes("play")) return "play";
  if (l.includes("stop")) return "stop";
  if (l.includes("rewind")) return "rewind";
  if (l.includes("forward")) return "forward";
  return "bolt";
}

function StatusChip({ icon, label, value, ok }) {
  return (
    <div className={"chip" + (ok ? " chip-ok" : " chip-bad")}>
      <Icon name={icon} size={15} />
      <span className="chip-label">{label}</span>
      <span className="chip-dot" />
      <span className="chip-val">{value}</span>
    </div>
  );
}

function Dashboard({ s, h, t, toast }) {
  return (
    <div className={"stage-inner"} data-rstyle={t.remoteStyle} data-size={t.size}>
      {/* Header */}
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark"><Icon name="signal" size={18} /></div>
          <div className="brand-txt">
            <div className="brand-title">TV Box Control</div>
            <div className="brand-sub">HD Capture · IR Bridge</div>
          </div>
        </div>
        <div className="status-row">
          <StatusChip icon="chip" label="Capture" value={s.capture === "online" ? "Online" : "Offline"} ok={s.capture === "online"} />
          <StatusChip icon="bolt" label="IR Bridge" value="Connected" ok={true} />
        </div>
        <div className="top-actions">
          <button className="iconbtn" title="Fullscreen" onClick={h.fullscreen}><Icon name="fullscreen" size={18} /></button>
          <button className="iconbtn" title="Settings — Tweaks live in the toolbar" onClick={h.settings}><Icon name="settings" size={18} /></button>
        </div>
      </header>

      {/* Main */}
      <main className="main">
        <section className="stage-screen">
          <LiveScreen
            channel={s.channel} on={s.on} muted={s.muted} volume={s.volume}
            mode={t.video} capture={s.capture}
            onRefresh={h.refresh} onMuteStream={h.mute} onFullscreen={h.fullscreen}
          />
          {toast && (
            <div className="toast" key={toast.id}>
              <Icon name={cmdIcon(toast.label)} size={16} />
              <span>{toast.label}</span>
            </div>
          )}
        </section>

        {s.remoteOpen ? (
          <Remote s={s} h={h} onClose={h.closeRemote} />
        ) : (
          <button className="remote-launcher" onClick={h.openRemote} title="Open remote">
            <Icon name="chip" size={18} />
            <span>Remote</span>
          </button>
        )}
      </main>
    </div>
  );
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const [on, setOn] = useState(true);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(24);
  const [chIndex, setChIndex] = useState(0);
  const [customCh, setCustomCh] = useState(null);
  const [chInput, setChInput] = useState("");
  const [keypadOpen, setKeypadOpen] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [remoteOpen, setRemoteOpen] = useState(true);
  const [log, setLog] = useState([]);
  const [toast, setToast] = useState(null);
  const idRef = useRef(0);
  const toastTimer = useRef(null);

  const channel = chIndex >= 0 ? CHANNELS[chIndex] : customCh;

  // apply accent var to root
  useEffect(() => {
    document.documentElement.style.setProperty("--accent", t.accent);
  }, [t.accent]);

  function send(label) {
    const e = { id: ++idRef.current, label, t: Date.now() };
    setLog((l) => [e, ...l].slice(0, 8));
    if (t.toasts) {
      setToast(e);
      clearTimeout(toastTimer.current);
      toastTimer.current = setTimeout(() => setToast(null), 1700);
    }
  }

  const h = {
    power: () => setOn((o) => { const n = !o; send(n ? "Power On" : "Power Off"); return n; }),
    mute: () => { if (!on) return; setMuted((m) => { send(m ? "Unmute" : "Mute"); return !m; }); },
    volUp: () => { setMuted(false); setVolume((v) => Math.min(100, v + 2)); send("Volume Up"); },
    volDown: () => { setVolume((v) => Math.max(0, v - 2)); send("Volume Down"); },
    chUp: () => { setChIndex((i) => { const b = i < 0 ? 0 : i; return (b + 1) % CHANNELS.length; }); setCustomCh(null); send("Channel Up"); },
    chDown: () => { setChIndex((i) => { const b = i < 0 ? 0 : i; return (b - 1 + CHANNELS.length) % CHANNELS.length; }); setCustomCh(null); send("Channel Down"); },
    nav: (d) => send("Navigate " + d),
    ok: () => send("OK / Select"),
    back: () => send("Back"),
    menu: () => send("Menu / Exit"),
    info: () => send("Info"),
    setChInput: (v) => setChInput(v.slice(0, 4)),
    pressDigit: (d) => setChInput((v) => (v + d).slice(0, 4)),
    clearInput: () => setChInput((v) => v.slice(0, -1)),
    toggleKeypad: () => setKeypadOpen((o) => !o),
    toggleDrawer: () => setDrawerOpen((o) => !o),
    go: () => {
      const num = chInput.trim();
      if (!num) return;
      const idx = CHANNELS.findIndex((c) => c.num === num.padStart(3, "0") || c.num === num);
      if (idx >= 0) { setChIndex(idx); setCustomCh(null); }
      else {
        setChIndex(-1);
        setCustomCh({ num: num.padStart(3, "0"), name: "DIRECT TUNE", genre: "LIVE", program: "Tuning channel…", next: "—", progress: 8 });
      }
      send("Going to channel " + num);
      setChInput("");
      setKeypadOpen(false);
    },
    adv: (cmd, label) => send(label || cmd),
    refresh: () => send("Refresh stream"),
    openRemote: () => setRemoteOpen(true),
    closeRemote: () => setRemoteOpen(false),
    fullscreen: () => { const el = document.documentElement; if (el.requestFullscreen) el.requestFullscreen().catch(() => {}); },
    settings: () => send("Open Tweaks ⚙ (toolbar)"),
  };

  const s = { on, muted, volume, channel, chInput, keypadOpen, drawerOpen, remoteOpen, capture: "online", log };

  const phone = t.preview === "phone";

  return (
    <div className={"stage" + (phone ? " stage-phone" : "")} style={{ "--accent": t.accent }}>
      {phone ? (
        <div className="phone-shell">
          <div className="phone-notch" />
          <div className="phone-screen force-mobile">
            <Dashboard s={s} h={h} t={t} toast={toast} />
          </div>
        </div>
      ) : (
        <Dashboard s={s} h={h} t={t} toast={toast} />
      )}

      <TweaksPanel>
        <TweakSection label="Theme" />
        <TweakColor label="Accent" value={t.accent}
          options={["#4d8dff", "#2dd4c4", "#f5b042", "#9b7bff"]}
          onChange={(v) => setTweak("accent", v)} />
        <TweakSection label="Layout" />
        <TweakRadio label="Preview" value={t.preview} options={["desktop", "phone"]}
          onChange={(v) => setTweak("preview", v)} />
        <TweakRadio label="Button size" value={t.size} options={["regular", "large"]}
          onChange={(v) => setTweak("size", v)} />
        <TweakSection label="Remote" />
        <TweakRadio label="Key style" value={t.remoteStyle} options={["subtle", "flat", "tactile"]}
          onChange={(v) => setTweak("remoteStyle", v)} />
        <TweakSection label="Screen" />
        <TweakSelect label="Video feed" value={t.video}
          options={["broadcast", "striped", "bars"]}
          onChange={(v) => setTweak("video", v)} />
        <TweakToggle label="Command toasts" value={t.toasts}
          onChange={(v) => setTweak("toasts", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
